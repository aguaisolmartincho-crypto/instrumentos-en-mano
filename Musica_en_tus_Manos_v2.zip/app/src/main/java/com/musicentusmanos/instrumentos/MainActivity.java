package com.musicentusmanos.instrumentos;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    final ArrayList<Product> products = new ArrayList<>();
    final ArrayList<Product> cart = new ArrayList<>();

    static class Product {
        String name, category, price, seller, description;
        Product(String n,String c,String p,String s,String d){name=n;category=c;price=p;seller=s;description=d;}
    }

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(14),dp(8),dp(14),dp(8)); return t;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        seed();
        home();
    }

    void seed(){
        products.add(new Product("Ibanez RG 7 cuerdas","Guitarras","$1.250.000","Música en tus Manos","Guitarra eléctrica de 7 cuerdas."));
        products.add(new Product("Marshall DSL20HR","Amplificadores","$980.000","Música en tus Manos","Cabezal valvular de 20 W."));
        products.add(new Product("Boss GE-7 Equalizer","Pedales","$180.000","Música en tus Manos","Ecualizador gráfico para guitarra."));
        products.add(new Product("Seymour Duncan Pickup","Accesorios","$320.000","Música en tus Manos","Micrófono para guitarra eléctrica."));
        products.add(new Product("Orange PPC212 OB","Gabinetes","$1.100.000","Música en tus Manos","Gabinete 2x12 con Vintage 30."));
    }

    void shell(String title){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,248,250));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=tv("🎸 "+title,21); h.setTextColor(Color.WHITE); h.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(28,22,38)); bar.addView(h,new LinearLayout.LayoutParams(0,dp(62),1));
        Button cartB=new Button(this); cartB.setText("🛒 "+cart.size()); cartB.setOnClickListener(v->cart());
        bar.addView(cartB,new LinearLayout.LayoutParams(dp(100),dp(62)));
        root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void home(){
        shell("Música en tus Manos");
        EditText search=new EditText(this); search.setHint("Buscar instrumentos...");
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout cats=new LinearLayout(this);
        for(String c:new String[]{"Todos","Guitarras","Amplificadores","Pedales"}){
            Button b=new Button(this); b.setText(c); b.setOnClickListener(v->showProducts(c));
            cats.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));
        }
        content.addView(cats);
        TextView title=tv("Productos destacados",20); content.addView(title);
        showCards(products);
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){
                ArrayList<Product> r=new ArrayList<>();
                for(Product p:products) if(p.name.toLowerCase().contains(s.toString().toLowerCase()) || p.category.toLowerCase().contains(s.toString().toLowerCase())) r.add(p);
                showCards(r);
            }
            public void afterTextChanged(android.text.Editable e){}
        });
        Button publish=new Button(this); publish.setText("＋ PUBLICAR INSTRUMENTO");
        publish.setOnClickListener(v->publish());
        content.addView(publish,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    void showProducts(String category){
        shell("Catálogo");
        TextView title=tv(category,21); content.addView(title);
        ArrayList<Product> r=new ArrayList<>();
        for(Product p:products) if(category.equals("Todos")||p.category.equals(category)) r.add(p);
        showCards(r);
    }

    void showCards(ArrayList<Product> list){
        if(content==null)return;
        // Preserve first controls when home is active; rebuild only card area by adding cards.
        for(Product p:list){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12),dp(8),dp(12),dp(8)); card.setBackgroundColor(Color.WHITE);
            TextView n=tv(p.name,18); n.setTextColor(Color.rgb(35,25,45)); card.addView(n);
            card.addView(tv(p.category+" • Vendedor: "+p.seller,13));
            TextView price=tv(p.price,18); price.setTextColor(Color.rgb(45,125,75)); card.addView(price);
            Button b=new Button(this); b.setText("Ver producto"); b.setOnClickListener(v->detail(p)); card.addView(b);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(145)); lp.setMargins(dp(8),dp(6),dp(8),dp(6));
            content.addView(card,lp);
        }
    }

    void detail(Product p){
        new AlertDialog.Builder(this).setTitle(p.name)
            .setMessage("Categoría: "+p.category+"\\nPrecio: "+p.price+"\\nVendedor: "+p.seller+"\\n\\n"+p.description)
            .setPositiveButton("Agregar al carrito",(d,w)->{cart.add(p); Toast.makeText(this,"Agregado al carrito",Toast.LENGTH_SHORT).show();})
            .setNeutralButton("Contactar vendedor",(d,w)->Toast.makeText(this,"Chat del vendedor: próximo módulo",Toast.LENGTH_SHORT).show())
            .setNegativeButton("Cerrar",null).show();
    }

    void cart(){
        shell("Carrito");
        if(cart.isEmpty()){ content.addView(tv("Tu carrito está vacío.",20)); return; }
        for(Product p:cart) content.addView(tv("• "+p.name+" — "+p.price,17));
        Button buy=new Button(this); buy.setText("CONTINUAR CON LA COMPRA");
        buy.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Compra").setMessage("El siguiente módulo conectará Mercado Pago, datos de envío y confirmación del pedido.").setPositiveButton("Aceptar",null).show());
        content.addView(buy);
    }

    void publish(){
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(dp(18),0,dp(18),0);
        EditText n=new EditText(this); n.setHint("Nombre del instrumento");
        EditText c=new EditText(this); c.setHint("Categoría");
        EditText p=new EditText(this); p.setHint("Precio");
        EditText d=new EditText(this); d.setHint("Descripción");
        f.addView(n);f.addView(c);f.addView(p);f.addView(d);
        new AlertDialog.Builder(this).setTitle("Publicar instrumento").setView(f)
            .setPositiveButton("Publicar",(x,w)->{
                products.add(new Product(n.getText().toString(),c.getText().toString(),p.getText().toString(),"Mi tienda",d.getText().toString()));
                Toast.makeText(this,"Publicación creada",Toast.LENGTH_LONG).show(); home();
            }).setNegativeButton("Cancelar",null).show();
    }
}
